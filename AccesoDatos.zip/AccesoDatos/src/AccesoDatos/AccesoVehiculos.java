package AccesoDatos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class AccesoVehiculos {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String BBDD = "jdbc:mysql://localhost/vehiculos";
	private static final String USUARIO = "jesus";
	private static final String PASSWORD = "jesuspw";


	public Connection conexionBBDD() {
		Connection conec = null;
		try{
			Class.forName(DRIVER);
			conec = DriverManager.getConnection(BBDD,USUARIO,PASSWORD);
			System.out.println("conexion hecha");

		} catch (Exception errores){
			System.err.println("se ha producido un error al conectar con la base de datos. \n"+errores);
		}
		return conec;
	}
	public void cerrarConexion(Connection conection) {
		try {
			conection.close();
		}catch(SQLException e) {
			System.err.println("se ha producido un error al conectar con la base de datos. \n"+e);
		}
	}
	public void getTableData(String tableName) {
		Connection conec = conexionBBDD();
		if (conec != null) {
			try {
				Statement consulta = conec.createStatement();
				ResultSet resultSet = consulta.executeQuery("SELECT * FROM " + tableName);

				ResultSetMetaData metaData = resultSet.getMetaData();
				int columnCount = metaData.getColumnCount();

				// Imprimir los nombres de las columnas
				for (int i = 1; i <= columnCount; i++) {
					System.out.print(metaData.getColumnName(i) + "\t\t");
				}
				System.out.println();

				// Imprimir los datos de cada fila
				while (resultSet.next()) {
					for (int i = 1; i <= columnCount; i++) {
						System.out.print(resultSet.getObject(i) + "\t\t");
					}
					System.out.println();
				}

				System.out.println("Datos de la tabla " + tableName + " recuperados correctamente");
				consulta.close();
			} catch (SQLException e) {
				System.err.println("Se ha producido un error al obtener los datos de la tabla " + tableName + "\n" + e);
			} finally {
				cerrarConexion(conec);
			}
		}
	}
	public void insertData(String datos) {
		Connection conec= conexionBBDD();
		if (conec!=null) {
			try {
				String consultaInsercion= "INSERT INTO vehiculos (Matricula, Marca, Modelo, Anyo,Potencia,Plazas,Deposito,Consumo,L_correcto,Observaciones)"+
						"VALUES "+datos;
				System.out.println(consultaInsercion);
				Statement consulta=conec.createStatement();
				consulta.executeUpdate(consultaInsercion);
				System.out.println("Datos insertados correctamente");
				consulta.close();
			}catch (SQLException e) {
				System.err.println("se ha producido un error al insertar en la base de datos.\n"+e);
			}finally {
				cerrarConexion(conec);
			}
		}
	}
	public void mostrarDatos(String columna, Object valor) {
	    Connection conec = conexionBBDD();
	    if (conec != null) {
	        try {
	            String consulta = "SELECT * FROM vehiculos WHERE " + columna + " = ?";
	            PreparedStatement statement = conec.prepareStatement(consulta);
	            statement.setObject(1, valor);

	            ResultSet resultSet = statement.executeQuery();
	            ResultSetMetaData metaData = resultSet.getMetaData();
	            int columnCount = metaData.getColumnCount();

	            // Imprimir los nombres de las columnas
	            for (int i = 1; i <= columnCount; i++) {
	                System.out.print(metaData.getColumnName(i)+"\t");
	            }
	            System.out.println();

	            // Imprimir los datos de cada fila
	            while (resultSet.next()) {
	                for (int i = 1; i <= columnCount; i++) {
	                    System.out.print(resultSet.getObject(i) + "\t\t");
	                }
	                System.out.println();
	            }

	            System.out.println("Registros encontrados correctamente");
	            statement.close();
	        } catch (SQLException e) {
	            System.err.println("Se ha producido un error al obtener los registros.\n" + e);
	        } finally {
	            cerrarConexion(conec);
	        }
	    }
	}
	public void eliminarRegistro(String columna, Object valor) {
	    Connection conec = conexionBBDD();
	    if (conec != null) {
	        try {
	            String consulta = "DELETE FROM vehiculos WHERE " + columna + " = ?";
	            PreparedStatement statement = conec.prepareStatement(consulta);
	            statement.setObject(1, valor);

	            int filasAfectadas = statement.executeUpdate();

	            System.out.println("Se han eliminado " + filasAfectadas + " registro(s) correctamente");

	            statement.close();
	        } catch (SQLException e) {
	            System.err.println("Se ha producido un error al eliminar el registro.\n" + e);
	        } finally {
	            cerrarConexion(conec);
	        }
	    }
	}
}


