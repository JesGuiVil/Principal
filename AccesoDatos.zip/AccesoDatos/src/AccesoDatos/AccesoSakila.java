package AccesoDatos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class AccesoSakila {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String BBDD = "jdbc:mysql://localhost/sakila";
	private static final String USUARIO = "root";
	private static final String PASSWORD = "root";


	public Connection conexionBBDD() {
		Connection conec = null;
		try{
			Class.forName(DRIVER);
			conec = DriverManager.getConnection(BBDD,USUARIO,PASSWORD);
			System.out.println("conexion hecha");

		} catch (Exception errores){
			System.err.println("se ha producido un error al conectar con la base de datos. \n"+errores);
		}
		return conec;
	}
	public void cerrarConexion(Connection conection) {
		try {
			conection.close();
		}catch(SQLException e) {
			System.err.println("se ha producido un error al conectar con la base de datos. \n"+e);
		}
	}
	public void getActor() {
		Connection conec= conexionBBDD();
		if (conec!=null) {
			try {
				String consultaSeleccion = "SELECT * FROM actor;";
				System.out.println(consultaSeleccion);
				Statement consulta=conec.createStatement();
				if(consulta.execute(consultaSeleccion)) {
					ResultSet resultSet= consulta.getResultSet();
					while(resultSet.next()) {
						System.out.println(resultSet.getInt("actor_id")+"\t"+resultSet.getString("first_name")+"\t"+resultSet.getString("last_name")+"\t"+resultSet.getTimestamp("last_update"));
					}
				}
				System.out.println("Datos recuperados correctamente");
				consulta.close();
			}catch (SQLException e) {
				System.err.println("Se ha producido un eror al insetar en la base de datos. \n"+e);
			}finally {
				cerrarConexion(conec);
			}

		}
	}
	public void getTableData(String tableName) {
	    Connection conec = conexionBBDD();
	    if (conec != null) {
	        try {
	            Statement consulta = conec.createStatement();
	            ResultSet resultSet = consulta.executeQuery("SELECT * FROM " + tableName);

	            ResultSetMetaData metaData = resultSet.getMetaData();
	            int columnCount = metaData.getColumnCount();

	            // Imprimir los nombres de las columnas
	            for (int i = 1; i <= columnCount; i++) {
	                System.out.print(metaData.getColumnName(i) + "\t\t");
	            }
	            System.out.println();

	            // Imprimir los datos de cada fila
	            while (resultSet.next()) {
	                for (int i = 1; i <= columnCount; i++) {
	                    System.out.print(resultSet.getObject(i) + "\t\t");
	                }
	                System.out.println();
	            }

	            System.out.println("Datos de la tabla " + tableName + " recuperados correctamente");
	            consulta.close();
	        } catch (SQLException e) {
	            System.err.println("Se ha producido un error al obtener los datos de la tabla " + tableName + "\n" + e);
	        } finally {
	            cerrarConexion(conec);
	        }
	    }
	}
	
}
