/**
 * 
 */
/**
 * @author 34620
 *
 */
module AccesoDatos {
	requires java.sql;
}