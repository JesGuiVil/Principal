/**
 * 
 */
/**
 * 
 */
module HashMap {
	requires java.desktop;
}