/**
 * 
 */
/**
 * 
 */
module trollwindow {
	requires java.desktop;
}